# iniCHORD
Library containing the codes for image series treatment.
